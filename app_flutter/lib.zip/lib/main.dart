import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'mqtt/mqtt_service.dart';

import 'ui/top_bar.dart';
import 'ui/display_panel.dart';
import 'ui/action_button.dart';
import 'ui/train_panel.dart';
import 'ui/trained_list.dart';
import 'ui/bottom_nav.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  /// MQTT
  late MqttService mqtt;

  /// TEXT HIỂN THỊ
  String text = "";

  /// DICTIONARY
  Map<String, String> dictionary = {};
  String currentSuggestion = "";

  /// DANH SÁCH
  List<String> allLetters =
      List.generate(26, (i) => String.fromCharCode(65 + i));

  List<String> trainedLetters = [];

  /// LOAD DICTIONARY
  Future<void> loadDictionary() async {
    final data = await rootBundle.loadString('assets/dictionary.txt');

    final lines = data.split('\n');

    for (var line in lines) {
      if (line.contains(':')) {
        final parts = line.split(':');
        dictionary[parts[0].trim()] = parts[1].trim();
      }
    }

    print("DICTIONARY LOADED: $dictionary");
  }

  @override
  void initState() {
    super.initState();

    loadDictionary();

    mqtt = MqttService();

    mqtt.connect(

      /// nhận gesture realtime
      onGesture: (g) {
        setState(() {
          text += g;

          /// giới thiệu từ
          currentSuggestion = dictionary[g] ?? "";

          /// tránh text quá dài
          if (text.length > 30) {
            text = text.substring(text.length - 30);
          }
        });
      },

      /// train xong 1 chữ
      onTrain: (letter) {
        setState(() {
          if (!trainedLetters.contains(letter)) {
            trainedLetters.add(letter);
          }
        });
      },

      /// nhận full list từ ESP
      onTrainList: (list) {
        setState(() {
          trainedLetters = list;
        });
      },
    );
  }

  @override
  void dispose() {
    mqtt.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: const Color(0xFF0F131C),

      body: SafeArea(
        child: Column(
          children: [

            /// 🔷 TOP BAR
            const TopBar(),

            /// 🔷 CONTENT
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),

                child: Column(
                  children: [

                    /// 🧠 OUTPUT
                    DisplayPanel(text: text),

                    /// 🔥 SUGGESTION
                    if (currentSuggestion.isNotEmpty)
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            text += " $currentSuggestion";
                            currentSuggestion = "";
                          });
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 12),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: const Color(0xFF00F2FF).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            currentSuggestion,
                            style: const TextStyle(
                              color: Color(0xFF00F2FF),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),

                    const SizedBox(height: 24),

                    /// 🔥 BUTTON NHẬN DẠNG
                    ActionButton(
                      onPressed: () {
                        mqtt.recognize();
                      },
                    ),

                    const SizedBox(height: 32),

                    /// 🧩 TRAIN PANEL
                    TrainPanel(
                      allLetters: allLetters,
                      trainedLetters: trainedLetters,
                      onTap: (l) {
                        mqtt.train(l);
                      },
                    ),

                    const SizedBox(height: 32),

                    /// 🔵 TRAINED LIST
                    TrainedList(trainedLetters: trainedLetters),

                    const SizedBox(height: 50),
                  ],
                ),
              ),
            ),

            /// 🔻 BOTTOM NAV
            const BottomNavBar(),
          ],
        ),
      ),
    );
  }
}