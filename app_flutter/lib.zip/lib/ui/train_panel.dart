import 'package:flutter/material.dart';

class TrainPanel extends StatelessWidget {
  final List<String> allLetters;
  final List<String> trainedLetters;
  final Function(String) onTap;

  const TrainPanel({
    super.key,
    required this.allLetters,
    required this.trainedLetters,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "CHƯA TRAIN",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        const SizedBox(height: 16),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 5,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
          ),
          itemCount: allLetters.length,
          itemBuilder: (context, i) {
            String l = allLetters[i];
            bool trained = trainedLetters.contains(l);

            return GestureDetector(
              onTap: () => onTap(l),
              child: Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: trained
                      ? const Color(0xFF00F2FF).withOpacity(0.2)
                      : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: trained
                        ? const Color(0xFF00F2FF)
                        : Colors.white.withOpacity(0.1),
                  ),
                ),
                child: Text(
                  l,
                  style: TextStyle(
                    color: trained
                        ? const Color(0xFF00F2FF)
                        : Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}