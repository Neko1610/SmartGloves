import 'package:flutter/material.dart';

class TrainedList extends StatelessWidget {
  final List<String> trainedLetters;

  const TrainedList({super.key, required this.trainedLetters});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "ĐÃ TRAIN",
          style: TextStyle(color: Colors.white, fontSize: 18),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 12,
          children: trainedLetters.map((l) {
            return Container(
              width: 50,
              height: 50,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFF00F2FF).withOpacity(0.2),
                border: Border.all(color: const Color(0xFF00F2FF)),
              ),
              child: Text(
                l,
                style: const TextStyle(
                  color: Color(0xFF00F2FF),
                  fontWeight: FontWeight.bold,
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }
}